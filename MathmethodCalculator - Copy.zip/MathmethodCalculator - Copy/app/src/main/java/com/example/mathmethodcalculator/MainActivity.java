package com.example.mathmethodcalculator;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.*;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.InputMismatchException;


public class MainActivity extends AppCompatActivity {
    EditText firstvalue, secondvalue, Mathmethod;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @SuppressLint("SetTextI18n")
    public void show(View v) {

            firstvalue = (EditText) findViewById(R.id.firstvalue);
            secondvalue = (EditText) findViewById(R.id.secondvalue);
            Mathmethod = (EditText) findViewById(R.id.Mathmethod);
            result = (TextView) findViewById(R.id.result);


        Toast.makeText(getApplicationContext(), (CharSequence) firstvalue, Toast.LENGTH_SHORT).show();

            double fvalue = Double.parseDouble(firstvalue.toString());
            double svalue = Double.parseDouble(secondvalue.toString());
            double total = Math.pow(fvalue, svalue);
            result.setText(String.valueOf(total));



        double result1;
        double Subresult;
        try {
            int MathUsed = Integer.parseInt(Mathmethod.toString());
            switch (MathUsed) {
                case 1:
                    result.setText((int) Math.abs(fvalue) + "\n" + Math.abs(svalue));
                    break;
                case 2:
                    result.setText((int) Math.pow(fvalue, svalue));
                    break;
                case 3:
                    result.setText((int) Math.min(fvalue,svalue));
                    break;
                case 4:
                    result.setText((int) Math.max(fvalue,svalue));
                    break;
                case 5:
                    result.setText((int) Math.floor(fvalue) + "\n" + Math.floor(svalue));
                    break;
                case 6:
                    result.setText((int) Math.ceil(fvalue) + "\n" + Math.ceil(svalue));
                    break;
                case 7:
                    result.setText((int) Math.round(fvalue) + "\n" + Math.round(svalue));
                    break;
                case 8:
                    result.setText((int) Math.sqrt(fvalue) + "\n" + Math.sqrt(svalue));
                    break;
                default: result.setText("Error!! Please Chose inside the Box.");
                    break;
            }
        } catch(InputMismatchException ex) {
            result.setText("MIsmatch occur");
            }
    }
}